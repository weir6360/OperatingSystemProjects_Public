/*
    Author: Alex Gale, Gabe Weir
    Assignment Number: 1
    Date of Submission: 10/21/21
    Name of this file: c.h
    Description of the program: Header for c.c to be used by 5ps.c
*/

char* c_return(int pid);