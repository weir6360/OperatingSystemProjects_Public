/*
    Author: Alex Gale, Gabe Weir
    Assignment Number: 1
    Date of Submission: 10/21/21
    Name of this file: t.h
    Description of the program: Header for t.c to be used by 5ps.c
 */
const char* t_return(int pid);
int read_utime(int pid);
int read_stime(int pid);