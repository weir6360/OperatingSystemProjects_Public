/*
    Author: Alex Gale, Gabe Weir
    Assignment Number: 1
    Date of Submission: 10/21/21
    Name of this file: v.h
    Description of the program: Header for v.c to be used by 5ps.c
*/

int v_return(int pid);