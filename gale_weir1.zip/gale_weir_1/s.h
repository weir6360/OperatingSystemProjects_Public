/*
    Author: Alex Gale, Gabe Weir
    Assignment Number: 1
    Date of Submission: 10/21/21
    Name of this file: s.h
    Description of the program: Header for s.c to be used by 5ps.c
*/

char s_return(int pid);