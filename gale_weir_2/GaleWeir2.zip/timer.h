/*
    Author: Alex Gale, Gabe Weir
    Assignment Number: 2
    Date of Submission: 11/11/2021
    Name of this file: timer.h
    Description of the program: Header file for timer.c
*/

void timer_handler(int timer_signal);

void start_timer();