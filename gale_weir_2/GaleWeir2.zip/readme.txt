/*
    Author: Alex Gale, Gabe Weir
    Assignment Number: 2
    Date of Submission: 11/11/2021
    Name of this file: readme.txt
*/

to compile: 
    gcc child.c -o child
    gcc srtfScheduler.c timer.c

usage: 
    ./a.out input.txt

notes: 
    This program was developed in a version of ubuntu that included a modern gui.
    It was tested in the class provided CLI ubuntu build and it still worked fine.
    Random number generation works properly, but prime number checking does not. It iterates through numbers but doesn't return actual primes.
    
    